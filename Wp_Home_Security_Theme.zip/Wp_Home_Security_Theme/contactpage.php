<?php 
/*
	Template Name: Contact Page
*/

get_header(); ?>

<section class="parallax_window_in short" data-parallax="scroll" data-image-src="<?php echo get_template_directory_uri().'/img/subheader_in_3.jpg' ?>" data-natural-width="1400" data-natural-height="350">
		<div id="sub_content_in">
			<div class="container">
				<h1>Contact us</h1>
                <p>"Get in touch with us"</p>
			</div>
		</div>
	</section><!-- End section -->
	
      <main>
        <div class="container margin_60_35">
        	<div class="row">
                
            <div class="col-md-9">
                	
              <!--<div id="map"></div><!-- end map-->
              
               <hr>
                    
              <div id="message-contact"></div>
                <form method="post" action="<?php echo get_stylesheet_directory_uri().'/assets/contact.php' ?>" id="contactform">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>First name</label>
                                <input type="text" class="form-control" id="name_contact" name="name_contact" >
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Last name</label>
                                <input type="text" class="form-control" id="lastname_contact" name="lastname_contact">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" id="email_contact" name="email_contact" class="form-control" >
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label>Phone number</label>
                                <input type="text" id="phone_contact" name="phone_contact" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Your message</label>
                                <textarea rows="5" id="message_contact" name="message_contact" class="form-control" style="height:100px;"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                            <label>Are you human? 3 + 1 =</label>
                            <input type="text" id="verify_contact" class=" form-control">
                            </div>
                            <input type="submit" value="Submit" class="btn_1 green medium add_bottom_30" id="submit-contact"/>
                        </div>
                    </div>
                </form>                    
           </div><!-- End col-md-9 -->
                
           <div class="col-md-3">
                	<div class="box_style_2">
                        <h5>Address</h5>
                            <p><?php echo get_theme_mod( 'contact_address') ?></p>
                             <h5>Contacts</h5>
                            <ul>
                            	 <li><strong>Phone Number</strong><br><a href="tel://<?php echo get_theme_mod( 'contact_phone' ) ?>"><?php echo get_theme_mod( 'contact_phone' ) ?></a></li>
                                <li><strong>Email</strong><br><a href="tel://<?php echo get_theme_mod( 'contact_email' ) ?>"><?php echo get_theme_mod( 'contact_email' ) ?></a></li>
                            </ul>
                    </div>
                    <div class="quote_banner"><a href="<?php echo get_theme_mod('contact_button_link'); ?>">Need a quotation?</a></div>
                </div><!-- End col-md-3 -->
            </div><!-- End row -->
        </div><!-- End container -->
	</main><!-- End main -->

<?php get_footer();
