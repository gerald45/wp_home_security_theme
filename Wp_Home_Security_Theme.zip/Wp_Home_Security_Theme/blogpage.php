<?php

get_header(); ?>

 <section class="parallax_window_in short" data-parallax="scroll" data-image-src="img/subheader_in_1.jpg" data-natural-width="1400" data-natural-height="350">
		<div id="sub_content_in">
			<div class="container">
				<h1>Our Blog</h1>
				<p>"Usu habeo equidem sanctus no ex melius"</p>
			</div>
		</div>
	</section><!-- End section -->

 <main>
        <div class="container margin_60_35">
            <div class="row">
                <div class="col-md-9">

<?php
// the query
$wpb_all_query = new WP_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>2)); ?>
 
<?php if ( $wpb_all_query->have_posts() ) : ?>
	    <!-- the loop -->
	    <?php while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); ?>
	        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
	         		<div class="post">
                        <figure class="animated"><a href="<?php the_permalink(); ?>" title="blog_post.html"><?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?><img src="<?php echo $url ?>"</a></figure>
                        <div class="post_info clearfix">
                            <div class="post-left">
                                <ul>
                                    <li><i class="icon-calendar-empty"></i> On <span><?php the_time() ?></span></li>
                                    <li><i class="icon-inbox-alt"></i> In <a href="#">Security</a></li>
                                    <li><i class="icon-tags"></i> Tags <a href="#">Works</a>, <a href="#">Personal</a></li>
                                </ul>
                            </div>
                            <div class="post-right"><i class="icon-comment"></i><a href="#">25 </a></div>
                        </div>
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <?php the_content() ?>
                        <a  href="<?php the_permalink(); ?>" class="btn_1" title="blog_post.html">Read more</a>
                    </div><!-- end post -->
	    <?php endwhile; ?>

	    <!-- end of the loop -->

    <?php wp_reset_postdata(); ?>
 
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>
                 
                    
                    <div class="text-center">
                        <ul class="pagination">
                            <li><a href="#">Prev</a></li>
                            <li class="active"><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#">Next</a></li>
                        </ul><!-- end pagination-->
                    </div>
                </div><!-- End col-md-9 -->
                
                <div class="col-md-3">
                <div class="box_style_1">
                    <div class="widget">
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Search...">
					</div>
				</div><!-- End Search -->
                
                <hr>
                
				<div class="widget">
					<h5>Categories</h5>
					<ul id="cat_nav">
                    	<li><a href="#">Security tips</a></li>
                        <li><a href="#">Office wiring</a></li>
                        <li><a href="#">Diagnosis</a></li>
                        <li><a href="#">Maintance</a></li>
                    </ul>
				</div><!-- End widget -->
              
               </div><!-- End box style 1 -->
            
				<div class="widget">
					<h4>Recent post</h4>
					<ul class="recent_post">
						<li>
						<i class="icon-calendar-empty"></i> 16th July, 2020
						<div><a href="#">It is a long established fact that a reader will be distracted </a></div>
						</li>
						<li>
						<i class="icon-calendar-empty"></i> 16th July, 2020
						<div><a href="#">It is a long established fact that a reader will be distracted </a></div>
						</li>
						<li>
						<i class="icon-calendar-empty"></i> 16th July, 2020
						<div><a href="#">It is a long established fact that a reader will be distracted </a></div>
						</li>
					</ul>
				</div><!-- End widget -->
                <hr>
				<div class="widget tags">
					<h4>Tags</h4>
					<a href="#">Lorem ipsum</a>
					<a href="#">Dolor</a>
					<a href="#">Long established</a>
					<a href="#">Sit amet</a>
					<a href="#">Latin words</a>
					<a href="#">Excepteur sint</a>
				</div><!-- End widget -->
                <hr>
                <div class="widget archives">
					<h4>Archives</h4>
					<ul class="list_2">		
                        <li><a href="#">May 2015</a></li>
                        <li><a href="#">April 2015</a></li>
                        <li><a href="#">March 2015</a></li>
                        <li><a href="#">February 2015</a></li>
                        <li><a href="#">January 2015</a></li>
                    </ul>
				</div><!-- End widget -->
                    
                </div><!-- End col-md-3 -->
            </div><!-- End row -->
        </div><!-- End container -->
	 </main><!-- End main -->
	
<?php get_footer();?>