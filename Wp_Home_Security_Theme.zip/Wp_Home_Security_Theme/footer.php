	<footer class="main-footer">

		<div class="container">

			<div class="row ">

				<div class="col-md-5">
					<img src="<?php echo wp_get_attachment_url(get_theme_mod( 'alarm-custom-logo-footer')) ?>" width="190"  alt="Home Alarms" data-retina="true" id="logo_footer">

					<div><?php echo get_theme_mod( 'alarm-company-summary-footer')?></div>
				</div>
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-6">
							<h3><?php echo get_theme_mod( 'alarm-footer-header-links');?></h3>
							<?php
										wp_nav_menu( array(
											'theme_location' => 'footer_menu',
											'container' => false
										) );
							?>
						</div>
						<div class="col-md-6" id="contact_bg">

							<h3>Contacts</h3>

							<ul id="contact_details_footer">

								<li id="address_footer"><?php echo get_theme_mod( 'alarm-footer-header-contacts-address' ); ?></li>

								<li id="phone_footer"><a href="tel://004542344599"><?php echo get_theme_mod( 'alarm-footer-header-contacts-phone') ?></a></li>

								<li id="email_footer"><a href="#0"><?php echo get_theme_mod( 'alarm-footer-header-contacts-email') ?></a></li>

							</ul>

						</div>
					</div>
				</div>
			</div><!-- End row -->	

			<div id="social_footer">

				<ul>

					<li><a href="<?php echo get_theme_mod( 'alarm-footer-social-facebook' ); ?>"><i class="icon-facebook"></i></a></li>

					<li><a href="<?php echo get_theme_mod( 'alarm-footer-social-twitter' ); ?>"><i class="icon-twitter"></i></a></li>

					<li><a href="<?php echo get_theme_mod( 'alarm-footer-social-google' ); ?>"><i class="icon-google"></i></a></li>

					<li><a href="<?php echo get_theme_mod( 'alarm-footer-social-pinterest' ); ?>"><i class="icon-pinterest"></i></a></li>

				</ul>

			</div>

		</div><!-- End container -->

		<div id="copy">

			<div class="container">

				<?php echo get_theme_mod( 'alarm-footer-copyright' ) ?>

			</div>

		</div><!-- End copy -->

	</footer><!-- End footer -->



	<div id="toTop"></div><!-- Back to top button -->

	

	<!-- Modal -->

	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

	  <div class="modal-dialog">

		<div class="modal-content">

		  <div class="modal-header">

			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

			<h4 class="modal-title" id="myModalLabel">Terms and conditions</h4>

		  </div>

		  <div class="modal-body">

			<h5>Ei aliquip regione</h5>

			<p>Lorem ipsum dolor sit amet, nibh omnium in eum, ne per omittam eligendi efficiantur. Eos at mundi dolorem, ad cum omnes utroque fastidii, est fastidii apeirian ea. Ne duo diceret partiendo voluptatum, vel at iudico civibus. Purto erant aliquando ex eos, at vel odio modo. In mel tollit reprehendunt, ut usu praesent posidonium cotidieque. Clita assentior maiestatis sea in, at electram voluptaria mel. Tale nusquam adipisci ad mel, partem civibus no vix, sea no accusata dignissim.</p>

			<h5>Altera vocibus eleifend</h5>

			<p>No dico agam error qui, adhuc dicat argumentum sit in. Munere virtute ea ius. Mei an graeco repudiandae disputationi, ex per animal invidunt, probo civibus ne duo. Mea ad officiis temporibus, vim ne idque probatus phaedrum, elit delectus indoctum te has. No sea reprimique necessitatibus, ut usu quas falli.</p>

		  </div>

		</div>

	  </div>

	</div>

	<?php wp_footer(); ?>

    <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript">
		//set up markers 
		var myMarkers = {"markers": [
				{"latitude": "51.511732", "longitude":"-0.123270", "icon": "<?php echo get_stylesheet_directory_uri(). '/img/map-marker2.png' ?>"}
			]
		};
		
		//set up map options
		

		$(document).ready(function(){
  			$("#map").mapmarker({
			zoom	: 14,
			center	: 'Covent Garden London',
			markers	: myMarkers
		});
	});
</script>

</body>

</html>