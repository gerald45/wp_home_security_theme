

<?php 
/*
	Template Name: Homepage
*/

get_header(); ?>



<main>

		<div id="full-slider-wrapper">

			<div id="layerslider" style="width:100%;height:650px;">

				<!-- first slide -->

				<?php for( $i = 1; $i<4; $i++ ) { ?>
					<div class="ls-slide <?php echo "slide".$i ?>" data-ls="slidedelay: 5000; transition2d:5;">

					<img src="<?php echo wp_get_attachment_url(get_theme_mod( 'alarm-slider'.$i.'-callout-image')) ?>" class="ls-bg" alt="Slide background">

					<h3 class="ls-l" style="top: 45%; left: 60px; font-size: 60px; white-space:nowrap; color:#fff; text-transform:uppercase; font-weight:900;" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;"><?php echo get_theme_mod( 'alarm-slider'.$i.'-callout-headline'); ?></h3>

					<p class="ls-l" style="top:53%; left:60px; color:#fff; font-size:28px; white-space:nowrap;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;"><?php echo get_theme_mod( 'alarm-slider'.$i.'-callout-text')?></p>

					<a class="ls-l button_intro " style="top:65%; left:60px;white-space: nowrap;" data-ls="durationin:2000;delayin:1300;easingin:easeOutElastic;" href="#">Read more</a>

				</div>
				<?php } ?>




			</div>

		</div><!-- End layerslider -->

	

		<div id="get_quote">

			<div class="container">

				<div class="row">

					<div class="col-md-9">

						<h3><?php echo get_theme_mod( 'alarm-homepage-callaction-text') ?></h3>

					</div>

					<div class="col-md-3">

						<a href="#home_quotation" class="btn_quote">Get an online quote</a>

					</div>

				</div><!-- End row -->

			</div><!-- End container -->

		</div><!-- End Get quote -->



		<div id="feat_home">

			<div class="container margin_60_25">
<?php
	for( $i = 1; $i<4; $i++ ) { ?>
		<div class="row">
			<?php
			$check1=0; $check2=0;
			if ($i===1) { $check1=1; $check2=3;
				} elseif ($i===2) { $check1=3; $check2=5;
				} elseif ($i===3) { $check1=5; $check2=7;
			}
				for( $g = $check1; $g<$check2; $g++ ) {?>
					
					<div class="col-md-6">

                        <div class="box_feat">

                            <span><img src="<?php echo wp_get_attachment_url(get_theme_mod( 'alarm_home_services_icon'.$g)) ?>" alt=""></span>

                            <h3><?php echo get_theme_mod( 'alarm-home-services-headline'.$g); ?></h3>

                            <p><?php echo get_theme_mod( 'alarm-home-services-description'.$g); ?></p>
                            
                        </div>

					</div>
					
				<?php }
			?>

		</div>
		
	<?php }
?>

			</div>

		</div><!-- End feat home -->




		<!-- quotation_wizard here -->
		<div id="home_quotation" class="container margin_60_35">
			<div class="row add_bottom_30">
				<div class="col-md-4">
					<div class="box_quote">
						<h3><strong>Calculate NOW</strong> your Quote!</h3>
						<p class="lead">Answer these questions in less than a minute.</p>
						<ul>
							<li><i class="icon_check_alt2"></i>Easier</li>
							<li><i class="icon_check_alt2"></i>Faster</li>
							<li><i class="icon_check_alt2"></i>Without obligation</li>
							<li><i class="icon_check_alt2"></i>30% Price off</li>
						</ul>
					</div>
				</div>
				<div class="col-md-8">
                <form id="custom" method="POST" class="add_bottom_30">
					<input id="website" name="website" type="text" value="">
					<!-- Leave for security protection, read docs for details. Delete this comment before to publish. -->
						<fieldset title="Step 1">
							<legend>Installation</legend>
							<h3>Where do you need to install the Alarm?</h3>
							<div class="form-group">
								<label><input type="radio" value="Apartment" id="apartment" name="location" class="icheck">Apartment</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="Villa" id="villa" name="location" class="icheck">Villa</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="Office" id="office" name="location" class="icheck">Office</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="Shop" id="shop" name="location" class="icheck">Shop</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="Warehouse" id="warehouse" name="location" class="icheck">Warehouse</label>
							</div>
						</fieldset><!-- End Step one -->

						<fieldset title="Step 2">
							<legend>House details</legend>
							<h3>Please answer to the following questions?</h3>
							<div class="form-group">
								<label>Do you have the armored door. If yes, how many?</label>
								<div class="styled-select">
									<select name="armored_door" id="armored_door">
										<option value="" selected="">Quantity</option>
										<option value="0">0</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="More than 3">More than 3</option>
									</select>
								</div>
							</div>
							<div class="form-group">
								<label>How many windows do you want to protect?</label>
								<div class="styled-select">
									<select name="windows" id="windows">
										<option value="" selected="">Quantity</option>
										<option value="0">0</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="More than 3">More than 3</option>
									</select>
								</div>
							</div>
							<div class="form-group">
								<label>How many areas do you want to protect?</label>
								<div class="styled-select">
									<select name="zones" id="zones">
										<option value="" selected="">Quantity</option>
										<option value="0">0</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="More than 3">More than 3</option>
									</select>
								</div>
							</div>
						</fieldset><!-- End Step two -->

						<fieldset title="Step 3">
							<legend>House options</legend>
							<h3>Does the house have secondary accesses?</h3>
							<div class="form-group">
								<label><input type="checkbox" value="Garden" id="garden" name="accesses[]" class="icheck">Garden</label>
							</div>
							<div class="form-group">
								<label><input type="checkbox" value="Balcony or terrace" id="balcony_terrace" name="accesses[]" class="icheck">Balcony or terrace</label>
							</div>
							<div class="form-group">
								<label><input type="checkbox" value="No one" id="no_one" name="accesses[]" class="icheck">No one</label>
							</div>
							<div class="form-group">
								<label><input type="checkbox" value="Not interested" id="not_interested" name="accesses[]" class="icheck">I'm not interested in protecting outdoor areas</label>
							</div>
						</fieldset><!-- End Step three -->

						<fieldset title="Step 4">
							<legend>Budget</legend>
							<h3>What is your budget?</h3>
							<div class="form-group">
								<label><input type="radio" value="300-500$" id="budget_1" name="budget" class="icheck">300-500$</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="500-1000$" id="budget_2" name="budget" class="icheck">500-1000$</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="More than 1000$" id="budget_3" name="budget" class="icheck">More than 1000$</label>
							</div>
							<div class="form-group">
								<label><input type="radio" value="I don't know" id="budget_4" name="budget" class="icheck">I don't know</label>
							</div>
						</fieldset><!-- End Step four -->

						<fieldset title="Step 5">
							<legend>Your details</legend>
							<div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <label>First name</label>
                                        <input type="text" class="form-control" id="firstname_quote" name="firstname_quote">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <label>Last name</label>
                                        <input type="text" class="form-control" id="lastname_quote" name="lastname_quote">
                                    </div>
                                </div>
                            </div><!-- End row -->
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" id="email_quote" name="email_quote">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <div class="form-group">
                                        <label>Telephone</label>
                                        <input type="text" class="form-control" id="phone_quote" name="phone_quote">
                                    </div>
                                </div>
                            </div><!-- End row -->
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Describe your property type as much as possible:rooms, electric equipment, volumes, etc...</label>
                                        <textarea name="message_general" id="message_general" style="height:100px" class="form-control"></textarea>
                                    </div>
									<div class="form-group">
										<input name="terms" type="checkbox" value="Yes" class="icheck"> <a data-toggle="modal" data-target="#myModal" href="#0">I accept terms and condition </a>
									</div>
                                </div>
                            </div><!-- End row -->
						</fieldset><!-- End Step five -->
						<input type="submit" class="finish" value="Finish!">
					</form>
				</div>
			</div><!-- End row -->

			<hr>

			<div class="row">
				
					<?php
                  
                    if( have_posts() ):

                        while (have_posts()): the_post();?>

							<?php
									// the query
									$wpb_all_query = new WP_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>3)); ?>
									 
									<?php if ( $wpb_all_query->have_posts() ) : ?>
										    <!-- the loop -->
										    <?php while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); ?>
																<div class="col-sm-4">
																	<figure class="animated">
																		<a href="<?php the_permalink(); ?>"><?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
																			<img src="<?php echo $url ?>" alt="" class="img-responsive">
																		</a>
																	</figure>
																	<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
																	<?php the_content(); ?>
															</div>
										    <?php endwhile; ?>

										    <!-- end of the loop -->

									    <?php wp_reset_postdata(); ?>
									 
									<?php else : ?>
									    <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
									<?php endif; ?>

                        <?php endwhile; ?>
                      
                   <?php endif; ?>

			</div><!-- End row -->
		</div><!-- End container -->
		<!-- end quotation_wizard -->


		



		<div class="bg_content magnific">

			<div>

				<h3>View our <strong>Video Demo</strong></h3>

				<p>

					Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex.

				</p>

				<a href="https://www.youtube.com/watch?v=cGPOX1ZpfEI" class="video"><i class="icon-play-circled2-1"></i></a>

			</div>

		</div><!-- End bg_content -->



	</main><!-- End main -->



<?php get_footer();

