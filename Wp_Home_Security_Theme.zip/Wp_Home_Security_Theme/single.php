<?php

get_header();

if (have_posts()) :
	while (have_posts()) : the_post(); ?>
	 <section class="parallax_window_in short" data-parallax="scroll" data-image-src="<?php echo get_template_directory_uri().'/img/subheader_in_1.jpg'; ?>" data-natural-width="1400" data-natural-height="350">
		<div id="sub_content_in">
			<div class="container">
				<h1><?php the_title(); ?></h1>
				<p></p>
			</div>
		</div>
	</section><!-- End section -->
	
      <main> 
        <div class="container margin_60_35">
            <div class="row">
                <div class="col-md-9">
                	<div class="post nopadding">
                     <img <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?> src="<?php echo $url ?>" alt="" class="img-responsive border">
					<div class="post_info clearfix">
						<div class="post-left">
							<!--<ul>
								<li><i class="icon-calendar-empty"></i>On <span>12 Nov 2020</span></li>
                                <li><i class="icon-inbox-alt"></i>In <a href="#">Top tours</a></li>
								<li><i class="icon-tags"></i>Tags <a href="#">Works</a> <a href="#">Personal</a></li>
							</ul>-->
						</div>
						<!--<div class="post-right"><i class="icon-comment"></i><a href="#">25 </a>Comments</div> -->
					</div>
					<h2><?php the_title(); ?></h2>
					<?php the_content(); ?>
				</div><!-- end post -->
                


                <!--<h4>3 comments</h4>
                
				 <div id="comments">
					<ol>
						<li>
						<div class="avatar"><a href="#"><img src="img/avatar1.jpg" alt=""></a></div>
						<div class="comment_right clearfix">
							<div class="comment_info">
								Posted by <a href="#">Anna Smith</a><span>|</span> 25 apr 2019 <span>|</span><a href="#">Reply</a>
							</div>
							<p>
								 Nam cursus tellus quis magna porta adipiscing. Donec et eros leo, non pellentesque arcu. Curabitur vitae mi enim, at vestibulum magna. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed sit amet sem a urna rutrumeger fringilla. Nam vel enim ipsum, et congue ante.
							</p>
						</div>
						<ul>
							<li>
							<div class="avatar"><a href="#"><img src="img/avatar2.jpg" alt=""></a></div>
                            
							<div class="comment_right clearfix">
								<div class="comment_info">
									Posted by <a href="#">Tom Sawyer</a><span>|</span> 25 apr 2019 <span>|</span><a href="#">Reply</a>
								</div>
								<p>
									 Nam cursus tellus quis magna porta adipiscing. Donec et eros leo, non pellentesque arcu. Curabitur vitae mi enim, at vestibulum magna. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed sit amet sem a urna rutrumeger fringilla. Nam vel enim ipsum, et congue ante.
								</p>
								<p>
									 Aenean iaculis sodales dui, non hendrerit lorem rhoncus ut. Pellentesque ullamcorper venenatis elit idaipiscingi Duis tellus neque, tincidunt eget pulvinar sit amet, rutrum nec urna. Suspendisse pretium laoreet elit vel ultricies. Maecenas ullamcorper ultricies rhoncus. Aliquam erat volutpat.
								</p>
							</div>
							</li>
						</ul>
						</li>
						<li>
						<div class="avatar"><a href="#"><img src="img/avatar3.jpg" alt=""></a></div>
                        
						<div class="comment_right clearfix">
							<div class="comment_info">
								Posted by <a href="#">Adam White</a><span>|</span> 25 apr 2019 <span>|</span><a href="#">Reply</a>
							</div>
							<p>
								Cursus tellus quis magna porta adipiscin
							</p>
						</div>
						</li>
					</ol>
				</div> End Comments -->
   				
				<!-- I temporarily remove the comment area here below (code was deleted) hint"if have_comments, the_comments" -->
               
				 
                </div><!-- End col-md-9 -->
                
                <div class="col-md-3">
                	<?php get_sidebar(); ?>
                </div><!-- End col-md-3 -->

            </div><!-- End row -->
        </div><!-- End container -->
	 </main><!-- End main -->	
	
	
	<?php endwhile;
	
	else :
		echo '<p>No content found</p>';
	
	endif;
	
get_footer();

?>