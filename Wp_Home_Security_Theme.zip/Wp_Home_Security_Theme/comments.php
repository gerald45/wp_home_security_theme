<?php
	
	if (post_password_required()) {
		return;
	}

?>
<div id="comments" class="comments-area">

	<?php 
		if (have_comments() ):
			//we have comments
	?>
		
		<ol class="comments-list">
			
			<?php
				$args = array(
					'walker'	 		=> null,
					'max_depth' 		=> 4,
					'style'				=> 'ol',
					'callback'			=> null,	
					'end-callback'		=> null,
					'reply_text'		=> 'Leave a reply to this comment',
					'page'				=> '',
					'per_page'			=> '',
					'avatar_size'		=> 32,
					'revese_top_level'	=> null,
					'reverse_children'	=> '',
					'format'			=> 'html5',
					'ping'				=>	false,
					'echo'				=> true

				);

				wp_list_comments($args); 
			?>
		</ol>

		<?php
			if(!comments_open() && get_comments_number() ):
		?>	
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', $domain = 'Alarm Promotions' ); ?></p>
		<?php
			endif;
		?>

	<?php
		endif;
	?>

	<?php
		//Moving the Comment Field to Bottom
		function wpb_move_comment_field_to_bottom( $fields ) {
			$comment_field = $fields['comment'];
				unset( $fields['comment'] );
			$fields['comment'] = $comment_field;
			return $fields;
		}
			 
			add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );

		$args = array(
			'fields' => apply_filters( 'comment_form_default_fields', array(

				    'author' =>
				      '<p class="comment-form-author form-group">' .
				      '<label for="author" style="display:none;">' . __( 'Name', 'domainreference' ) . '</label><input id="author" class="form-control style_2 required" placeholder="Enter Name*" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
				      '" required="required" /></p>',

				    'email' =>
				      '<p class="comment-form-email form-group"><label for="email" style="display:none;">' . __( 'Email', 'domainreference' ) . '</label><input id="email" class="form-control style_2 required email" placeholder="Enter Email*" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
				      '" required="required" /></p>'
		    	)

			),

			'comment_field' => '<p class="comment-form-comment form-group"><label for="comment" style="display:none;">' . _x( 'Comment', 'noun' ) . '</label><textarea id="comment" class="form-control style_2 " placeholder="Write your comment here*" name="comment" rows="8" required="required"></textarea></p>',

			'submit_button'        => '<input name="%1$s" type="submit" id="%2$s" class="%3$s btn_1" value="%4$s" />',
			'title_reply'          => __( 'Leave a Comment' )

		);
		comment_form( $args );


	?>

</div>

