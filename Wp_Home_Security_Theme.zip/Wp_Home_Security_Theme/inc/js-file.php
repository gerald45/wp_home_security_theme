<!-- Common scripts -->

	

	<script src="<?php echo get_stylesheet_directory_uri(). '/js/common_scripts_min.js' ?>"></script>

	<script src="<?php echo get_stylesheet_directory_uri(). '/js/functions.js' ?>"></script>



	<!-- LayerSlider script files -->

	<script src="<?php echo get_stylesheet_directory_uri(). '/layerslider/js/greensock.js' ?>"></script>

	<script src="<?php echo get_stylesheet_directory_uri(). '/layerslider/js/layerslider.transitions.js' ?>"></script>

	<script src="<?php echo get_stylesheet_directory_uri(). '/layerslider/js/layerslider.kreaturamedia.jquery.js' ?>"></script>

	<script src="<?php echo get_stylesheet_directory_uri(). '/js/slider_func.js' ?>"></script>

	

	<!-- Specific scripts -->
	<script src="<?php echo get_stylesheet_directory_uri(). '/js/jquery.validate.js' ?>"></script>

	<script src="<?php echo get_stylesheet_directory_uri(). '/js/jquery.stepy.min.js' ?>"></script>

	<script src="<?php echo get_stylesheet_directory_uri(). '/js/quotation-validate.js' ?>"></script>

	<!-- GOOGLE MAP -->
	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
	<script  type="text/javascript" src="<?php echo get_stylesheet_directory_uri(). '/js/mapmarker.jquery.js'?>"></script>
	
	<!-- Form validation -->
	<script src="<?php echo get_stylesheet_directory_uri(). '/assets/validate.js'?>"></script>