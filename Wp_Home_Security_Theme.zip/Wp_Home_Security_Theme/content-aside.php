 <aside>
   <div class="post">
                        <figure class="animated"><a href="<?php the_permalink(); ?>" title="blog_post.html"><?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?><img src="<?php echo $url ?>" class="img-responsive"></a></figure>
                        <div class="post_info clearfix">
                            <div class="post-left">
                                <ul>
                                    <li s><i class="icon-calendar-empty"></i> On <span><?php the_date(); ?></span></li>
                                    <li><i class="icon-inbox-alt"></i> In <?php echo the_category(' '); ?></li>
                                    <li><i class="icon-tags"></i> Tags <?php echo the_tags(' '); ?></li>
                                </ul>
                            </div>
                           <!-- <div class="post-right"><i class="icon-comment"></i><a href="#">25 </a></div> -->
                        </div>
                        <h2 class="blog-post-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <?php the_content() ?>
                        <a  href="<?php the_permalink(); ?>" class="btn_1" title="blog_post.html">Read more</a>
                    </div><!-- end post -->
 </aside>

 