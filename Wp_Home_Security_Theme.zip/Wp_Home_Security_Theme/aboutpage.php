<?php 
/*
	Template Name: Aboutpage
*/

get_header(); ?>



	<section class="parallax_window_in short" data-parallax="scroll" data-image-src="<?php echo get_template_directory_uri().'/img/subheader_in_3.jpg' ?>" data-natural-width="1400" data-natural-height="350">
			<div id="sub_content_in">
				<div class="container">
					<h1>About Us</h1>
					<p>"Usu habeo equidem sanctus no ex melius"</p>
				</div>
			</div>
	</section><!-- End section -->

	<main>
		<div class="container margin_60">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div id="intro">
                        <p><img src="<?php echo wp_get_attachment_url(get_theme_mod( 'about_intro_image')) ?>" alt="" class="img-responsive"></p>
                        <h2><?php echo get_theme_mod('about_intro_heading') ?></h2>
                        <p class="lead">
                            <?php echo get_theme_mod('about_intro_statement') ?>
                        </p>
                    </div>
                </div>
            </div><!-- End row -->

			<hr>

			<div class="row">
				<div class="col-sm-4">
					<?php echo get_theme_mod('about_details_summary') ?>
				</div>
				<div class="col-sm-7 col-sm-offset-1">
					<ul class="feat" id="about">

					<?php 
						for( $i = 1; $i<5; $i++ ) { ?>
							<li>

								<i class="icon_check_alt2"></i>
								<h4><?php echo get_theme_mod( 'about_service_headline'.$i ) ?></h4>
								<p>
									<?php echo get_theme_mod( 'about_service_description'.$i ) ?></h4>
								</p>
							</li>
						<?php }
					?>
					</ul>
				</div>
			</div><!-- End row -->

			<hr>

			<div class="text-center">
				<h2><?php echo get_theme_mod( 'about_team_heading' ) ?></h2>
				<p class="lead">
					<?php echo get_theme_mod( 'about_team_statement' ) ?>
				</p>
			</div>
			
			<!--Team Carousel -->
			<div class="row">
				<div class="owl-carousel team-carousel">

				<?php for( $i = 1; $i<5; $i++ ) { ?>
					<div class="team-item">
						<div class="team-item-img">
							<img src="<?php echo wp_get_attachment_url(get_theme_mod( 'about_team_image_member'.$i )) ?>" alt="">
							<div class="team-item-detail">
								<div class="team-item-detail-inner">
									<h4><?php echo get_theme_mod( 'about_team_name_member'.$i ) ?></h4>
									<p><?php echo get_theme_mod( 'about_team_description_member'.$i ) ?></p>
									<!--<ul class="social">
										<li><a href="#0"><i class="icon-facebook"></i></a></li>
										<li><a href="#0"><i class="icon-twitter"></i></a></li>
										<li><a href="#0"><i class="icon-google"></i></a></li>
										<li><a href="#0"><i class="icon-linkedin"></i></a></li>
									</ul>-->
								</div>
							</div>
						</div>
					</div>
				<?php } ?>
				</div>
			</div><!--End Team Carousel-->
		</div><!-- End container -->

		<section class="promo_full">
			<div class="promo_full_wp">
				<div>
					<h3><?php echo get_theme_mod( 'about_testimony_heading' ) ?><span><?php echo get_theme_mod( 'about_testimony_subheading' ) ?></span></h3>
					<div class="container">
						<div class="row">
							<div class="col-md-8 col-md-offset-2">
								<div class="carousel_testimonials">
									
								<?php 
									for( $t = 1; $t<4; $t++ ) { ?>

										<div>
											<div class="box_overlay">
												<div class="pic">
													<figure><img src="<?php echo wp_get_attachment_url(get_theme_mod( 'about_testimony_image_customer'.$t)) ?>" alt="" class="img-circle">
													</figure>
													<h4><?php echo get_theme_mod( 'about_testimony_customername'.$t ) ?><small><?php echo get_theme_mod( 'about_testimony_date'.$t ) ?></small></h4>
												</div>
												<div class="comment">
													<?php echo get_theme_mod( 'about_testimony_statement'.$t ) ?>
												</div>
											</div><!-- End box_overlay -->
										</div>

									<?php }
								 ?>
								</div><!-- End carousel_testimonials -->
								
							</div><!-- End col-md-8 -->
						</div><!-- End row -->
					</div><!-- End container -->
				</div><!-- End promo_full_wp -->
			</div><!-- End promo_full -->
		</section><!-- End section -->
	</main><!-- End main -->



<?php get_footer( ); ?>

<!-- SPECIFIC SCRIPTS -->
	<script>
		'use strict';
		$(".team-carousel").owlCarousel({
			items: 1,
			loop: true,
			margin: 10,
			autoplay: false,
			smartSpeed: 300,
			responsiveClass: false,
			responsive: {
				320: {
					items: 1,
				},
				768: {
					items: 2,
				},
				1000: {
					items: 3,
				}
			}
		});
	</script>

