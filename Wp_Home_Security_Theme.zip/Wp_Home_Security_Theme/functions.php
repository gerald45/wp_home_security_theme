<?php

function alarm_script_enqueue() {
    wp_enqueue_style( 'bootstrap-css', get_template_directory_uri().'/css/bootstrap.min.css', array(),'','all');
    wp_enqueue_style( 'menu-css', get_template_directory_uri().'/css/menu.css', array(),'','all');
    wp_enqueue_style( 'responsive-css', get_template_directory_uri().'/css/responsive.css', array(),'','all');
    wp_enqueue_style( 'elegant_font', get_template_directory_uri().'/css/elegant_font/elegant_font.min.css', array(),'','all');
    wp_enqueue_style( 'fontello', get_template_directory_uri().'/css/fontello/css/fontello.min.css', array(),'','all');
    wp_enqueue_style( 'magnific-popup', get_template_directory_uri().'/css/magnific-popup.min.css', array(),'','all');
    wp_enqueue_style( 'alarmstyle-css', get_template_directory_uri().'/css/alarmstyle.css', array(),'','all');
    wp_enqueue_style( 'layerslider', get_template_directory_uri().'/layerslider/css/layerslider.css', array(),'','all');
    wp_enqueue_style( 'grey-css', get_template_directory_uri().'/css/skins/square/grey.css', array(),'','all');
    wp_enqueue_style( 'blog-css', get_template_directory_uri().'/css/blog.css', array(),'','all');
    wp_enqueue_style( 'custom-css', get_template_directory_uri().'/css/custom.css', array(),'','all');
    wp_enqueue_style( 'favicon', get_template_directory_uri().'/img/favicon.ico', array(),'','all');
    wp_enqueue_script( 'JQuery', get_template_directory_uri().'/js/jquery-2.2.4.min.js', array(),'2.2.4', false);
    wp_enqueue_script( 'JQuery-validate', get_template_directory_uri().'/js/jquery.validate.js', array(),'', false);

    //footer js
    wp_enqueue_script( 'common-scripts-min', get_template_directory_uri().'/js/common_scripts_min.js', array(),'', true);
    wp_enqueue_script( 'functions', get_template_directory_uri().'/js/functions.js', array(),'', true);
    wp_enqueue_script( 'layerslider-greensock', get_template_directory_uri().'/layerslider/js/greensock.js', array(),'', true);
    wp_enqueue_script( 'layerslider-transitions', get_template_directory_uri().'/layerslider/js/layerslider.transitions.js', array(),'', true);
    wp_enqueue_script( 'layerslider-kreaturamedia.jquery', get_template_directory_uri().'/layerslider/js/layerslider.kreaturamedia.jquery.js', array(),'', true);
    wp_enqueue_script( 'slider-func', get_template_directory_uri().'/js/slider_func.js', array(),'', true);
    wp_enqueue_script( 'jquery-validate', get_template_directory_uri().'/js/jquery.validate.js', array(),'', true);
    wp_enqueue_script( 'jquery-stepy', get_template_directory_uri().'/js/jquery.stepy.min.js', array(),'', true);
    wp_enqueue_script( 'quotation-validate', get_template_directory_uri().'/js/quotation-validate.js', array(),'', true);
    wp_enqueue_script( 'mapmarker', get_template_directory_uri().'/js/mapmarker.jquery.js', array(),'', true);
    wp_enqueue_script( 'validate', get_template_directory_uri().'/assets/validate.js', array(),'', true);

}
add_action( 'wp_enqueue_scripts', 'alarm_script_enqueue');


/* Activate Nav Menu Option */
function alarm_register_nav_menu() {
	register_nav_menu( 'primary', 'Header Navigation Menu' );
	register_nav_menu( 'footer_menu', 'Footer Navigation Menu' );
}
add_action('after_setup_theme', 'alarm_register_nav_menu');

/*Load Header Customizer Function from folder "functions"*/
require get_template_directory().'/functions/header-customizer.php';

/*Load Homepage Customizer Function from folder "functions"*/
require get_template_directory().'/functions/homepage-customizer.php';

/*Load Footer Customizer Function from folder "functions"*/
require get_template_directory().'/functions/footer-customizer.php';

/*Load Footer Customizer Function from folder "functions"*/
require get_template_directory().'/functions/contactpage-customizer.php';

/*Load Footer Customizer Function from folder "functions"*/
require get_template_directory().'/functions/aboutpage-customizer.php';

/*Load theme supports Function from folder "functions"*/
require get_template_directory().'/js/mapmarker_func.jquery.php';




//side bar
function alarm_widget_setup(){
	register_sidebar( 
		array(
			'name' 			=> 'blog_sidebar1',
			'id'			=> 'sidebar_1',
			'class'			=> 'custom',
			'description'	=> 'Blog Sidebar',
			'before_widget'	=> '<aside id="%1$s" class="widget sidebar-1 %2$s">',
			'after_widget'	=> '</aside>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'	=> '</h5>',
		) 
	);

	register_sidebar( 
		array(
			'name' 			=> 'blog_sidebar2',
			'id'			=> 'sidebar_2',
			'class'			=> 'custom',
			'description'	=> 'Blog Sidebar',
			'before_widget'	=> '<aside id="%1$s" class="widget sidebar-2 %2$s">',
			'after_widget'	=> '</aside>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'	=> '</h4>',
		) 
	);

	register_sidebar( 
		array(
			'name' 			=> 'blog_sidebar3',
			'id'			=> 'sidebar_3',
			'class'			=> 'custom',
			'description'	=> 'Blog Sidebar',
			'before_widget'	=> '<aside id="%1$s" class="widget sidebar-2 %2$s">',
			'after_widget'	=> '</aside>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'	=> '</h4>',
		) 
	);
}

add_action('widgets_init', 'alarm_widget_setup');






//Edit Recent Comment Widget
require get_parent_theme_file_path( '/functions/my-recent-post.php' );

add_action( 'widgets_init', function(){
	unregister_widget( 'WP_Widget_Recent_Posts' );
	register_widget( 'My_WP_Widget_Recent_Posts' );
});



add_theme_support( 'post-formats', array('aside','image','video'));
add_theme_support( 'html5', array('search-form') );


/*How to add numeric pagination in your WordPress theme*/
 
function wordpress_numeric_post_nav() {
    if( is_singular() )
        return;
    global $wp_query;
    /* Stop the code if there is only a single page page */
    if( $wp_query->max_num_pages <= 1 )
        return;
    $paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
    $max   = intval( $wp_query->max_num_pages );
    /*Add current page into the array */
    if ( $paged >= 1 )
        $links[] = $paged;
    /*Add the pages around the current page to the array */
    if ( $paged >= 3 ) {
        $links[] = $paged - 1;
        $links[] = $paged - 2;
    }
    if ( ( $paged + 2 ) <= $max ) {
        $links[] = $paged + 2;
        $links[] = $paged + 1;
    }
    echo '<div class="navigation"><ul>' . "\n";
    /*Display Previous Post Link */
    if ( get_previous_posts_link() )
        printf( '<li>%s</li>' . "\n", get_previous_posts_link() );
    /*Display Link to first page*/
    if ( ! in_array( 1, $links ) ) {
        $class = 1 == $paged ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );
        if ( ! in_array( 2, $links ) )
            echo '<li>…</li>';
    }
    /* Link to current page */
    sort( $links );
    foreach ( (array) $links as $link ) {
        $class = $paged == $link ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
    }
    /* Link to last page, plus ellipses if necessary */
    if ( ! in_array( $max, $links ) ) {
        if ( ! in_array( $max - 1, $links ) )
            echo '<li>…</li>' . "\n";
        $class = $paged == $max ? ' class="active"' : '';
        printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
    }
    /** Next Post Link */
    if ( get_next_posts_link() )
        printf( '<li>%s</li>' . "\n", get_next_posts_link() );
    echo '</ul></div>' . "\n";
}
 
add_filter("the_content", "break_text");
function break_text($text){
    $length = 500;
    if(strlen($text)<$length+10) return $text;//don't cut if too short

    $break_pos = strpos($text, ' ', $length);//find next space after desired length
    $visible = substr($text, 0, $break_pos);
    return balanceTags($visible) . " […]";
} 