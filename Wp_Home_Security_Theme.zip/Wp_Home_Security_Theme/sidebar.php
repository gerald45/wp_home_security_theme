	                <div class="box_style_1">
	                <div class="widget">
						<?php get_search_form(); ?>
					</div><!-- End Search -->
                	<hr>
                	<div id="sidebar" class="widget">
							<?php dynamic_sidebar( 'sidebar_1' ); ?>
					</div><!-- End widget -->
	               </div><!-- End box style 1 -->
	            	
	            	<div class="widget">
						<?php dynamic_sidebar( 'sidebar_2' ); ?>
					</div><!-- End widget -->
	                <hr>
					<div class="widget tags">
						<?php dynamic_sidebar( 'sidebar_3' ); ?>
					</div><!-- End widget -->
	                <hr>

	                <!-- <div class="widget archives">
						<h4>Archives</h4>
						<ul class="list_2">		
	                        <li><a href="#">May 2015</a></li>
	                        <li><a href="#">April 2015</a></li>
	                        <li><a href="#">March 2015</a></li>
	                        <li><a href="#">February 2015</a></li>
	                        <li><a href="#">January 2015</a></li>
	                    </ul>
					</div> End widget -->
        