<!DOCTYPE html>

<html lang="en">



<head>

	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="Alarm Promotions - Number 1 Alarms and security systems">

	<meta name="author" content="Gerald Homboy">

	<title>Alarm Promotions- Alarms and security systems</title>

	<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(). '/img/favicon.ico' ?>" type="image/x-icon">
	<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(). '/img/apple-touch-icon-57x57-precomposed.png' ?>" type="image/x-icon">
	<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(). '/img/apple-touch-icon-72x72-precomposed.png' ?>" type="image/x-icon">
	<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(). '/img/apple-touch-icon-114x114-precomposed.png' ?>" type="image/x-icon">
	<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(). '/img/apple-touch-icon-144x144-precomposed.png' ?>" type="image/x-icon">

	<?php wp_head(); ?>

    

	<!-- call jquery -->
	
	<script type="text/javascript">
		$().ready(function() {
		// validate the comment form when it is submitted
		$("#commentform").validate();
		});
	</script>


	<!--[if lt IE 9]>

      <script src="js/html5shiv.min.js"></script>

      <script src="js/respond.min.js"></script>

    <![endif]-->

    <!-- call css files here -->
   

</head>



<body <?php body_class(); ?>>



	<div id="preloader">

		<div class="sk-spinner sk-spinner-wave">

			<div class="sk-rect1"></div>

			<div class="sk-rect2"></div>

			<div class="sk-rect3"></div>

			<div class="sk-rect4"></div>

			<div class="sk-rect5"></div>

		</div>

	</div><!-- End Preload -->



	<div class="layer"></div><!-- Mobile menu overlay mask -->



	<!-- Header================================================== -->

	<header>

		<div id="top_line">

			<div class="container">

				<div class="row">

					<div class="col-sm-4 hidden-xs">

						<span id="tag_line"><?php echo get_theme_mod( 'alarm-top-header-tagline')?></span>

					</div>

					<div class="col-sm-8">

						<ul id="top_links">

							<li><span id="opening"><?php echo get_theme_mod( 'alarm-top-header-schedule')?></span><a href="tel://<?php echo get_theme_mod( 'alarm-top-header-telephone')?>" id="phone_top"><?php echo get_theme_mod( 'alarm-top-header-telephone')?></a></li>

							<li class="hidden-xs"><a id="email_top" href="#"><?php echo get_theme_mod( 'alarm-top-header-email')?></a></li>

						</ul>

					</div>

				</div><!-- End row -->

			</div><!-- End container-->

		</div><!-- End top line-->



		<div class="container">

			<div class="row">

				<div class="col-xs-3">

					<div id="logo">

						<a href="index.html"><img src="<?php echo wp_get_attachment_url(get_theme_mod( 'alarm-custom-logo')) ?>" height="54" alt="Home Alarms" data-retina="true"></a>

					</div>

				</div>

				<nav class="col-xs-9">

					<a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="javascript:void(0);"><span>Menu mobile</span></a>

					<div class="main-menu">

						<div id="header_menu">

							<img src="<?php echo wp_get_attachment_url(get_theme_mod( 'alarm-custom-logo')) ?>" width="190" height="44" alt="Home Alarms" data-retina="true">

						</div>

						<a href="#" class="open_close" id="close_in"><i class="icon_close"></i></a>

							<?php
								wp_nav_menu( array(
									'theme_location' => 'primary',
									'container' => false
								) );
							?>

					</div><!-- End main-menu -->

					<script type="text/javascript">
						$(document).ready(function(){
							$('ul#menu-menu-1 >li').addClass('submenu');
							$('ul#menu-menu-1 >li >a').addClass('show-submenu');
							//$( 'ul#menu-header-menu >li >a' ).append( '<i class="icon-down-open-mini"></i>' );
						});
					</script>

				</nav>

			</div>

		</div><!-- container -->

	</header><!-- End Header -->