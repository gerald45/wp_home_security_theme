<?php //theme supports

function alarm_theme_support_setup(){
	add_theme_support( 'post-thumbnails' ); 
}
add_action('after_setup_theme', 'alarm_theme_support_setup');


add_theme_support( 'html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption') );
?>