<?php /*Header Section*/
function alarm_custom_header($wp_customize) {
	$wp_customize-> add_section('alarm_custom_header_section', array(
		'title' => 'Header Section'
	));

	//top header info
	$wp_customize->add_setting('alarm-top-header-tagline', array(
		'default' => 'Example Tagline Here'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-top-header-tagline-control', array(
		'label' => 'Tagline Text',
		'section' => 'alarm_custom_header_section',
		'settings' => 'alarm-top-header-tagline'
	)));

	$wp_customize->add_setting('alarm-top-header-schedule', array(
		'default' => 'Monday-Sat 8:00am-10pm'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-top-header-schedule-control', array(
		'label' => 'Days and Time Available',
		'section' => 'alarm_custom_header_section',
		'settings' => 'alarm-top-header-schedule'
	)));

	$wp_customize->add_setting('alarm-top-header-telephone', array(
		'default' => '760-705-8792'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-top-header-telephone-control', array(
		'label' => 'Telephone Number',
		'section' => 'alarm_custom_header_section',
		'settings' => 'alarm-top-header-telephone'
	)));

	$wp_customize->add_setting('alarm-top-header-email', array(
		'default' => 'Info@AlarmPromotions.org'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-top-header-email-control', array(
		'label' => 'Telephone Number',
		'section' => 'alarm_custom_header_section',
		'settings' => 'alarm-top-header-email'
	)));


	//header logo
	$wp_customize->add_setting('alarm-custom-logo');

	$wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'alarm-custom-logo-control', array(
		'label' => 'Header Logo',
		'section' => 'alarm_custom_header_section',
		'settings' => 'alarm-custom-logo',
		'width' => '380',
		'height' => '88'
	)));

}
add_action( 'customize_register', 'alarm_custom_header');

?>