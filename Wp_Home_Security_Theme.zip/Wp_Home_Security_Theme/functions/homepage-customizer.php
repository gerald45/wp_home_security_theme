<?php
/*Homepage Body*/
function alarm_homepage_body($wp_customize) {

	$wp_customize->add_panel( 'homepage_panel', array(
	 	'priority'       => 10,
	  'capability'     => 'edit_theme_options',
	  'theme_supports' => '',
	  'title'          => __('Home Page', 'Alarm Theme'),
	  'description'    => __('Several settings pertaining Alarm Theme', 'Alarm Theme'),
	));

	//slider section area
	$wp_customize->add_section('alarm-slider-callout-section', array(
		'title' => 'Slider Section',
		'panel' => 'homepage_panel'
	));

		for( $i = 1; $i<4; $i++ ) {
           $wp_customize->add_setting('alarm-slider'.$i.'-callout-headline', array(
			'default' => 'Example Headline Text'
			));
           $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-slider'.$i.'-callout-headline-control', array(
			'label' =>  'Slider'.$i." ".'Heading',
			'section' => 'alarm-slider-callout-section',
			'settings' => 'alarm-slider'.$i.'-callout-headline'
			)));

           $wp_customize->add_setting('alarm-slider'.$i.'-callout-text', array(
			'default' => 'Example paragraph Text'
			));
	        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-slider'.$i.'-callout-text-control', array(
			'label' => 'Slider'.$i." ". 'Text',
			'section' => 'alarm-slider-callout-section',
			'settings' => 'alarm-slider'.$i.'-callout-text',
			'type' => 'textarea'
			)));

			$wp_customize->add_setting('alarm-slider'.$i.'-callout-image');
			$wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'alarm-slider'.$i.'-callout-image-control', array(
			'label' => 'Slider'.$i." ". ' Image',
			'section' => 'alarm-slider-callout-section',
			'settings' => 'alarm-slider'.$i.'-callout-image',
			'width' => '1600',
			'height' => '650'
			)));
         }


	//Call Action Section
	$wp_customize-> add_section('alarm_homepage_callaction_section', array(
		'title' => 'Homepage Call Action',
		'panel' => 'homepage_panel'
	));

	$wp_customize->add_setting('alarm-homepage-callaction-text', array(
		'default' => 'Looking for a quality and affordable service?'
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-homepage-callaction-text-control', array(
		'label' => 'Call Action Text',
		'section' => 'alarm_homepage_callaction_section',
		'settings' => 'alarm-homepage-callaction-text',
		'type' => 'text'
	)));


	//homepage services
	$wp_customize-> add_section('alarm_homepage_body_section', array(
		'title' => 'Homepage Product and Services',
		'panel' => 'homepage_panel'
	));

	for( $i = 1; $i<7; $i++ ) {
		$wp_customize->add_setting('alarm_home_services_icon'.$i);

		$wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'alarm-home-services-icon'.$i.'-control', array(
			'label' => 'Icon'.$i." ". 'Image',
			'section' => 'alarm_homepage_body_section',
			'settings' => 'alarm_home_services_icon'.$i
		)));

		$wp_customize->add_setting('alarm-home-services-headline'.$i, array(
			'default' => 'Headline Here'
		));

		$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-home-services-headline'.$i.'-control', array(
			'label' => 'Service Headline'.$i,
			'section' => 'alarm_homepage_body_section',
			'settings' => 'alarm-home-services-headline'.$i,
			'type' => 'text'
		)));

		$wp_customize->add_setting('alarm-home-services-description'.$i, array(
			'default' => 'Description Here'
		));

		$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-home-services-description'.$i.'-control', array(
			'label' => 'Service Description'.$i,
			'section' => 'alarm_homepage_body_section',
			'settings' => 'alarm-home-services-description'.$i,
			'type' => 'textarea'
		)));

	}

	$wp_customize->add_setting( 'themeslug_dropdownpages_setting_id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'themeslug_sanitize_dropdown_pages',
) );

$wp_customize->add_control( 'themeslug_dropdownpages_setting_id', array(
  'type' => 'dropdown-pages',
  'section' => 'alarm_homepage_callaction_section', // Add a default or your own section
  'label' => __( 'Custom Dropdown Pages' ),
  'description' => __( 'This is a custom dropdown pages option.' ),
) );

function themeslug_sanitize_dropdown_pages( $page_id, $setting ) {
  // Ensure $input is an absolute integer.
  $page_id = absint( $page_id );

  // If $page_id is an ID of a published page, return it; otherwise, return the default.
  return ( 'publish' == get_post_status( $page_id ) ? $page_id : $setting->default );
}

$wp_customize->add_section('alarm-slider-callout-section', array(
		'title' => 'Slider Section',
		'panel' => 'homepage_panel'
	));


$wp_customize->add_section('alarm-home-video-section', array(
		'title' => 'Video Section',
		'panel' => 'homepage_panel'
));



$wp_customize->add_setting('alarm_homepage_video', array(
	'type' 				=> 'theme_mod',
	'capability'		=> 'edit_theme_options',
	'sanitize_callback' => 'absint'
));

$wp_customize->add_control(new WP_Customize_Media_Control($wp_customize,'alarm_homepage_video_control', array(
	'section'		=> 'alarm-home-video-section',
	'settings'		=> 'alarm_homepage_video',
	'label'			=> 'Video',
	'mime_type' 	=> 'video'
)));

}
add_action( 'customize_register', 'alarm_homepage_body');

?>