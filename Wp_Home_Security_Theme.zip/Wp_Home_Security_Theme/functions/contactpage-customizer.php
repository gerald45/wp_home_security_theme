<?php

	function alarm_contacts ($wp_customize) {
		$wp_customize->add_panel( 'contact_panel', array(
		  'capability'     => 'edit_theme_options',
		  'theme_supports' => '',
		  'title'          => __('Contact Page', 'Alarm Theme'),
		  'description'    => __('Several settings pertaining Alarm Theme Contact Page', 'Alarm Theme'),
		));

		$wp_customize-> add_section('sidebar_address_section', array(
			'title' => 'Side Bar - Address',
			'panel' => 'contact_panel'

		));

		$wp_customize->add_setting('contact_address');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'contact-address-control', array(
			'label' => 'Contact Address',
			'section' => 'sidebar_address_section',
			'settings' => 'contact_address',
			'type'	   => 'textarea'
		)));

		$wp_customize-> add_section('sidebar_contacts_section', array(
			'title' => 'Side Bar - Contacts Details',
			'panel' => 'contact_panel'

		));

		$wp_customize->add_setting('contact_phone');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'contact-phone-control', array(
			'label' => 'Contact Phone',
			'section' => 'sidebar_contacts_section',
			'settings' => 'contact_phone',
			'type'	   => 'text'
		)));

		$wp_customize->add_setting('contact_email');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'contact-email-control', array(
			'label' => 'Contact Email',
			'section' => 'sidebar_contacts_section',
			'settings' => 'contact_email',
			'type'	   => 'text'
		)));

		$wp_customize-> add_section('sidebar_contacts_button', array(
			'title' => 'Side Bar - Contact Button',
			'panel' => 'contact_panel'

		));

		$wp_customize->add_setting('contact_button_caption');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'contact-button-caption-control', array(
			'label' => 'Contact Button Caption',
			'section' => 'sidebar_contacts_button',
			'settings' => 'contact_button_caption',
			'type'	   => 'text'
		)));

		$wp_customize->add_setting('contact_button_link', array(
			'capability' => 'edit_theme_options'
		));

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'contact-button-link-control', array(
			'label' => 'Contact Button Link',
			'section' => 'sidebar_contacts_button',
			'settings' => 'contact_button_link',
			'type'	   => 'text'
		)));


	}

	add_action( 'customize_register', 'alarm_contacts');

?>