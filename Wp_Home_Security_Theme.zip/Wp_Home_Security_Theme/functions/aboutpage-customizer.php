<?php

	function alarm_about_us_page ($wp_customize) {
		$wp_customize->add_panel( 'about_us_panel', array(
		  'capability'     => 'edit_theme_options',
		  'theme_supports' => '',
		  'title'          => __('About Page', 'Alarm Theme'),
		  'description'    => __('Several settings pertaining Alarm Theme About Page', 'Alarm Theme'),
		));


		//Intro Section
		$wp_customize-> add_section('about_intro_section', array(
			'title' => 'Intro Section',
			'panel' => 'about_us_panel'

		));

		$wp_customize->add_setting('about_intro_image');

		$wp_customize->add_control(new WP_Customize_Cropped_Image_Control ($wp_customize, 'about_intro_image_control', array(
			'label' => 'Intro Image',
			'section' => 'about_intro_section',
			'settings' => 'about_intro_image',
			'width' => '1200',
			'height' => '600'
		)));

		$wp_customize->add_setting('about_intro_heading');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_intro_heading_control', array(
			'label' => 'Intro Heading',
			'section' => 'about_intro_section',
			'settings' => 'about_intro_heading',
			'type'	   => 'text'
		)));

		$wp_customize->add_setting('about_intro_statement');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_intro_statement_control', array(
			'label' => 'Intro Statement',
			'section' => 'about_intro_section',
			'settings' => 'about_intro_statement',
			'type'	   => 'textarea'
		)));



		//Details Section
		$wp_customize-> add_section('about_details_section', array(
			'title' => 'Details Section',
			'panel' => 'about_us_panel'

		));

		$wp_customize->add_setting('about_details_summary');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_details_summary_control', array(
			'label' => 'Details Summary(Mission/Vision)',
			'section' => 'about_details_section',
			'settings' => 'about_details_summary',
			'type'	   => 'textarea'
		)));
		

		for( $i = 1; $i<5; $i++ ) {
			$wp_customize->add_setting('about_service_headline'.$i, array(
			'default' => 'Professional Service'
			));

			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'about_service_headline'.$i.'-control', array(
				'label' => 'About Service Headline'.$i,
				'section' => 'about_details_section',
				'settings' => 'about_service_headline'.$i,
				'type' => 'text'
			)));

			$wp_customize->add_setting('about_service_description'.$i, array(
			'default' => 'Eum purto epicurei cotidieque at, ius luptatum invidunt no.'
			));

			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'about_service_description'.$i.'-control', array(
				'label' => 'Service Description'.$i,
				'section' => 'about_details_section',
				'settings' => 'about_service_description'.$i,
				'type' => 'textarea'
			)));
		}

		//Team Section
		$wp_customize-> add_section('about_team_section', array(
			'title' => 'Team Section',
			'panel' => 'about_us_panel'

		));

		$wp_customize->add_setting('about_team_heading');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_team_heading_control', array(
			'label' => 'Team Heading',
			'section' => 'about_team_section',
			'settings' => 'about_team_heading',
			'type'	   => 'text'
		)));

		$wp_customize->add_setting('about_team_statement');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_team_statement_control', array(
			'label' => 'Team Statement',
			'section' => 'about_team_section',
			'settings' => 'about_team_statement',
			'type'	   => 'textarea'
		)));

		for( $i = 1; $i<5; $i++ ) {
			$wp_customize->add_setting('about_team_name_member'.$i, array(
			'default' => 'Gerald Homboy'
			));

			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'about_team_name_member'.$i.'-control', array(
				'label' => 'Team Member-'.$i." ". 'Name',
				'section' => 'about_team_section',
				'settings' => 'about_team_name_member'.$i,
				'type' => 'text'
			)));

			$wp_customize->add_setting('about_team_description_member'.$i, array(
			'default' => 'Eum purto epicurei cotidieque at, ius luptatum invidunt no.'
			));

			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'about_team_description_member'.$i.'-control', array(
				'label' => 'Team Member-'.$i." ". 'Description',
				'section' => 'about_team_section',
				'settings' => 'about_team_description_member'.$i,
				'type' => 'textarea'
			)));

			$wp_customize->add_setting('about_team_image_member'.$i);

			$wp_customize->add_control(new WP_Customize_Cropped_Image_Control ($wp_customize, 'about_team_image_member'.$i.'_control', array(
				'label' => 'Team Member-'.$i." ". 'Image',
				'section' => 'about_team_section',
				'settings' => 'about_team_image_member'.$i,
				'width' => '458',
				'height' => '540'
			)));
		}

		//Team Testimony
		$wp_customize-> add_section('about_testimony_section', array(
			'title' => 'Testimony Section',
			'panel' => 'about_us_panel'

		));

		$wp_customize->add_setting('about_testimony_heading');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_testimony_heading_control', array(
			'label' => 'Testimony Heading',
			'section' => 'about_testimony_section',
			'settings' => 'about_testimony_heading',
			'type'	   => 'text'
		)));

		$wp_customize->add_setting('about_testimony_subheading');

		$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_testimony_subheading_control', array(
			'label' => 'Testimony Sub-heading',
			'section' => 'about_testimony_section',
			'settings' => 'about_testimony_subheading',
			'type'	   => 'textarea'
		)));

		
		for( $t = 1; $t<4; $t++ ) {

			$wp_customize->add_setting('about_testimony_customername'.$t);

			$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_testimony_customername'.$t.'_control', array(
				'label' => 'Testimony Customer Name'.$t,
				'section' => 'about_testimony_section',
				'settings' => 'about_testimony_customername'.$t,
				'type'	   => 'text'
			)));
			$wp_customize->add_setting('about_testimony_date'.$t);

			$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_testimony_date'.$t.'_control', array(
				'label' => 'Testimony Customer Date'.$t,
				'section' => 'about_testimony_section',
				'settings' => 'about_testimony_date'.$t,
				'type'	   => 'text'
			)));

			$wp_customize->add_setting('about_testimony_image_customer'.$t);

			$wp_customize->add_control(new WP_Customize_Cropped_Image_Control ($wp_customize, 'about_testimony_image_customer'.$t.'_control', array(
				'label' => 'Testimony Customer-'.$t." ". 'Image',
				'section' => 'about_testimony_section',
				'settings' => 'about_testimony_image_customer'.$t
			)));

			$wp_customize->add_setting('about_testimony_statement'.$t);

			$wp_customize->add_control(new WP_Customize_Control ($wp_customize, 'about_testimony_statement'.$t.'_control', array(
				'label' => 'Testimony Statement'.$t,
				'section' => 'about_testimony_section',
				'settings' => 'about_testimony_statement'.$t,
				'type'	   => 'textarea'
			)));
		}



	}

	add_action( 'customize_register', 'alarm_about_us_page');

?>