<?php
/*Footer Section*/
function alarm_custom_footer ($wp_customize) {

	$wp_customize->add_panel( 'contact_panel', array(
	 	'priority'       => 10,
	  'capability'     => 'edit_theme_options',
	  'theme_supports' => '',
	  'title'          => __('Footer', 'Alarm Theme'),
	  'description'    => __('Several settings pertaining Alarm Theme', 'Alarm Theme'),
	));

	$wp_customize-> add_section('contact_address', array(
		'title' => 'Address',
		'panel' => 'contact_panel'

	));
	


	//Footer logo
	$wp_customize->add_setting('alarm-custom-logo-footer');

	$wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'alarm-custom-logo-footer-control', array(
		'label' => 'Footer Logo',
		'section' => 'footer_column1_section',
		'settings' => 'alarm-custom-logo-footer',
		'width' => '380',
		'height' => '88'
	)));

	$wp_customize->add_setting('alarm-company-summary-footer', array(
		'default' => 'Write short summary of the company and its services'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-company-summary-control', array(
		'label' => 'Company Summary',
		'section' => 'footer_column1_section',
		'settings' => 'alarm-company-summary-footer',
		'type' 	   => 'textarea'
	)));

	$wp_customize->add_setting('alarm-footer-header-links', array(
		'default' => 'Links Header Here'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-header-links-control', array(
		'label' => 'Links Header',
		'section' => 'footer_column2_section',
		'settings' => 'alarm-footer-header-links',
		'type' 	   => 'text'
	)));


	$wp_customize->add_setting('alarm-footer-header-contacts', array(
		'default' => 'Links Header Here'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-header-contacts-control', array(
		'label' => 'Contacts Header',
		'section' => 'footer_column3_section',
		'settings' => 'alarm-footer-header-contacts',
		'type' 	   => 'text'
	)));

	$wp_customize->add_setting('alarm-footer-header-contacts-address', array(
		'default' => 'Address Here'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-header-contacts-address-control', array(
		'label' => 'Contact Address',
		'section' => 'footer_column3_section',
		'settings' => 'alarm-footer-header-contacts-address',
		'type' 	   => 'textarea'
	)));

	$wp_customize->add_setting('alarm-footer-header-contacts-phone', array(
		'default' => 'Address Here'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-header-contacts-phone-control', array(
		'label' => 'Contact Phone',
		'section' => 'footer_column3_section',
		'settings' => 'alarm-footer-header-contacts-phone',
		'type' 	   => 'text'
	)));

	$wp_customize->add_setting('alarm-footer-header-contacts-email', array(
		'default' => 'Address Here'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-header-contacts-email-control', array(
		'label' => 'Contact Email',
		'section' => 'footer_column3_section',
		'settings' => 'alarm-footer-header-contacts-email',
		'type' 	   => 'text'
	)));


	$wp_customize->add_setting('alarm-footer-social-facebook', array(
		'default' => 'https://www.facebook.com/'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-social-facebook-control', array(
		'label' => 'Facebook Link',
		'section' => 'footer_bottom_section',
		'settings' => 'alarm-footer-social-facebook',
		'type' 	   => 'text'
	)));

	$wp_customize->add_setting('alarm-footer-social-twitter', array(
		'default' => 'https://www.twitter.com/'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-social-twitter-control', array(
		'label' => 'Twitter Link',
		'section' => 'footer_bottom_section',
		'settings' => 'alarm-footer-social-twitter',
		'type' 	   => 'text'
	)));

	$wp_customize->add_setting('alarm-footer-social-google', array(
		'default' => 'https://www.google.com/'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-social-google-control', array(
		'label' => 'Google Link',
		'section' => 'footer_bottom_section',
		'settings' => 'alarm-footer-social-google',
		'type' 	   => 'text'
	)));

	$wp_customize->add_setting('alarm-footer-social-pinterest', array(
		'default' => 'https://www.pinterest.com/'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-social-pinterest-control', array(
		'label' => 'Pinterest Link',
		'section' => 'footer_bottom_section',
		'settings' => 'alarm-footer-social-pinterest',
		'type' 	   => 'text'
	)));

	$wp_customize->add_setting('alarm-footer-copyright', array(
		'default' => '© Alarm Company 2018 - All rights reserved.'
	));
	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'alarm-footer-copyright-control', array(
		'label' => 'Copy Right Text',
		'section' => 'footer_bottom_section',
		'settings' => 'alarm-footer-copyright',
		'type' 	   => 'textarea'
	)));




}
add_action( 'customize_register', 'alarm_custom_footer');
?>