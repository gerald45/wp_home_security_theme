<?php get_header(); ?>
 <section class="parallax_window_in short" data-parallax="scroll" data-image-src="<?php echo get_template_directory_uri().'/img/subheader_in_1.jpg'; ?>" data-natural-width="1400" data-natural-height="350">
        <div id="sub_content_in">
            <div class="container">
                <h1>Our Blog</h1>
                <p>"Usu habeo equidem sanctus no ex melius"</p>
            </div>
        </div>
    </section><!-- End section -->
 <main>
     <div class="container margin_60_35">
          <div class="row">
              <div class="col-md-9">
                  <?php
                  
                    if( have_posts() ):
                        while (have_posts()): the_post();?>
                            <?php get_template_part( 'content',get_post_format() ); ?>
                        <?php endwhile; ?>
                        <?php wordpress_numeric_post_nav(); ?>
                   <?php endif; ?>
              </div>

              <div class="col-md-3">
                
                    <?php get_sidebar(); ?>
                    
                </div><!-- End col-md-3 -->
          </div>
     </div>
 </main>

<?php get_footer(); ?>